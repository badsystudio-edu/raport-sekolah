// ============================================
// KONFIGURASI - WAJIB DIISI SEBELUM DIPAKAI
// ============================================
// Tempel URL Web App Apps Script Anda di sini, yang berakhiran /exec
// Cara mendapatkannya: di editor Apps Script -> Deploy -> Manage deployments
// -> salin "Web app URL".
const GAS_URL = 'PASTE_URL_WEB_APP_DISINI/exec';
